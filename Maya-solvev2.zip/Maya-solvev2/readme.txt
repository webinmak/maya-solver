================================================================================
  GRAND ASSESSMENT SUBMITTER – SETUP & INSTRUCTIONS
  Version 2.0 (Direct API Submission)
================================================================================

  Author: Tanatswa Venacio Makata
  GitHub: https://github.com/webinmak

================================================================================
  DISCLAIMER
================================================================================

  This tool automates the submission of Grand Assessment tests on the Maya
  portal. It is an experimental prototype intended for legitimate academic
  use only. Unauthorised or illicit use is prohibited .

================================================================================
  SETUP (One‑Time Installation)
================================================================================

  1. Download / copy all extension files into a single folder:
       manifest.json
       popup.html
       popup.js
       content.js
       background.js
       icon1.png        (your custom icon)

  2. Open Google Chrome and go to:
       chrome://extensions/

  3. Turn ON "Developer mode" (toggle in the top‑right corner).

  4. Click the "Load unpacked" button.

  5. Select the folder containing your extension files.

  6. The extension icon (icon1.png) should now appear in your Chrome toolbar.

================================================================================
  HOW TO USE (Every Time You Take a Test)
================================================================================

  1. Log in to the Maya portal as usual.

  2. Navigate to your Grand Assessment page.
     The URL should look like:
     https://maya.adityauniversity.in/grand-assessment/[assessment-id]

  3. The assessment must be in "Active" state (NOT already submitted).

  4. Click the extension icon in your Chrome toolbar.

  5. In the popup, click the green "RUN" button.

  6. The extension will:
       - Fetch all questions and answers 
       - Build the submission payload.
       - Send it directly to the server.

  7. The popup will show progress messages:
       "Loading questions..."
       "Submitting..."
       "Submitted!"

  8. IMPORTANT – AFTER THE EXTENSION FINISHES SUBMISSION:
       DO NOT click anything else on the page.
       DO NOT refresh the page.
       DO NOT navigate away immediately.

       Simply close the popup, go back to your dashboard, and refresh the page.
       You will see the test status changed to "Completed".

================================================================================
  TROUBLESHOOTING
================================================================================

  ❌ "No roll number found"
     → You are not logged in. Log in to Maya first.

  ❌ "No assessment ID in URL"
     → You are not on a valid Grand Assessment page.
     → Make sure the URL contains "/grand-assessment/".

  ❌ "Failed to load questions" / "Server error"
     → The assessment may already be submitted.
     → Check your dashboard – it might already show "Completed".

  ❌ "Network error"
     → Check your internet connection.
     → Make sure the API endpoint is accessible.

  ❌ Extension icon doesn't appear
     → Go to chrome://extensions/ and reload the extension.
     → Check that icon1.png is in the same folder.

================================================================================
  NOTES
================================================================================

  • This extension does NOT interact with the DOM (no clicking, no scrolling).
  • It submits the test in under 2 seconds.
  • All answers are marked as correct .
  • Random time_taken values are injected (15–75 seconds per question).
  • After a successful submission, the extension will open my
    GitHub page in a new tab (you can close that tab).

================================================================================
  CONTACT
================================================================================

  For technical issues,  or querys, contact:
  Tanatswa Venacio Makata

================================================================================