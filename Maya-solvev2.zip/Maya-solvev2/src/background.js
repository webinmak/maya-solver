chrome.runtime.onInstalled.addListener(() => {
  console.log('Grand Assessment Submitter installed.');
});

// Listen for the openGitHub message from content.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'openGitHub') {
    chrome.tabs.create({ url: 'https://github.com/webinmak' });
    sendResponse({ status: 'opened' });
    return true;
  }
  return false;
});