document.getElementById('runBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) {
    updateStatus('No active tab.', 'error');
    return;
  }

  // Ensure content script is injected
  try {
    await chrome.tabs.sendMessage(tab.id, { action: 'ping' });
  } catch (e) {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['src/content.js']
    });
  }

  updateStatus('⏳ Submitting...', 'info');
  chrome.tabs.sendMessage(tab.id, { action: 'run' });
});

function updateStatus(text, type = 'info') {
  const el = document.getElementById('status');
  el.textContent = '● ' + text;
  el.className = 'status';
  if (type === 'error') el.style.color = '#e74c3c';
  else if (type === 'success') el.style.color = '#2ecc71';
  else el.style.color = '#ccc';
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.status) {
    const type = message.isError ? 'error' : 'success';
    updateStatus(message.status, type);
  }
});

// Show assessment ID from the page
async function updateAssessmentId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  try {
    const response = await chrome.tabs.sendMessage(tab.id, { action: 'getAssessmentId' });
    if (response && response.id) {
      document.getElementById('assessmentId').textContent = response.id.substring(0, 10) + '...';
    }
  } catch (e) {}
}
updateAssessmentId();